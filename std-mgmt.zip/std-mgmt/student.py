#!/usr/bin/env python
# Dev: Gopal Dasbairagya
# 15 April,2020
from tkinter import messagebox
from tkinter import ttk #provite combobox
from tkinter import *
import datetime
import pymysql

class Student:
    '''frame is responsible for the design '''
    def __init__(self, root):
        self.root = root
        self.root.title("Student Management System")
        self.root.geometry("1350x730+100+70")

        title = Label(self.root, text="Student Management System", bd=10, relief=GROOVE, font=("times new roman", 30, "bold"), bg="yellow", fg="black")
        title.pack(side=TOP, fill=X)

        #all variables
        self.roll_no = StringVar()
        self.name = StringVar()
        self.email = StringVar()
        self.phone = StringVar()
        self.gender = StringVar()
        self.dob = StringVar()
        self.search_by = StringVar()
        self.search_txt = StringVar()


        #1.Form Frame ----------------------------------------------------------------------------------------------------
        #form frame will place in root frame
        form_frame = Frame(self.root, bd=4, relief=RIDGE, bg="orange")
        form_frame.place(x=20, y=100, width=450, height=600)

        #form title
        form_title = Label(form_frame, text="Manage Students", bg="orange", fg="white", font=("times new roman", 20, "bold"))
        form_title.grid(row=0, columnspan=2, pady=20)

        #fields & labels will be place in form frame
        #roll
        lbl_roll = Label(form_frame, text="Roll No", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_roll.grid(row=1, column=0, pady=10, padx=20, sticky='w')

        txt_roll = Entry(form_frame, textvariable=self.roll_no, font=("times new roman", 16, "bold"), bd=5, relief=GROOVE)
        txt_roll.grid(row=1, column=1, pady=10, padx=20, sticky='w')

        #name
        lbl_name = Label(form_frame,  text="Name", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_name.grid(row=2, column=0, pady=10, padx=20, sticky='w')

        txt_name = Entry(form_frame, textvariable=self.name, font=("times new roman", 16, "bold"), bd=5, relief=GROOVE)
        txt_name.grid(row=2, column=1, pady=10, padx=20, sticky='w')
        #email
        lbl_email = Label(form_frame, text="Email", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_email.grid(row=3, column=0, pady=10, padx=20, sticky='w')

        txt_email = Entry(form_frame, textvariable=self.email,  font=("times new roman", 16, "bold"), bd=5, relief=GROOVE)
        txt_email.grid(row=3, column=1, pady=10, padx=20, sticky='w')

        #gender combobox
        lbl_gender = Label(form_frame, text="Gender", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_gender.grid(row=4, column=0, pady=10, padx=20, sticky='w')

        # list = ['Male', 'Female']
        # combo_gender = OptionMenu(form_frame, self.gender, *list)
        # combo_gender.config(width=25)
        # self.gender.set('Male')
        combo_gender = ttk.Combobox(form_frame, textvariable=self.gender,  font=("times new roman", 16, "bold"), state="readonly")
        combo_gender['values']= ('Male', 'Female', 'Other')
        # self.gender.set('Male')
        combo_gender.grid(row=4, column=1, pady=10, padx=20, sticky='w')
        lbl_contact = Label(form_frame, text="Contact", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_contact.grid(row=5, column=0, pady=10, padx=20, sticky='w')

        txt_contact = Entry(form_frame, textvariable=self.phone,  font=("times new roman", 16, "bold"), bd=5, relief=GROOVE)
        txt_contact.grid(row=5, column=1, pady=10, padx=20, sticky='w')
        #dob
        lbl_dob = Label(form_frame, text="D.O.B", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_dob.grid(row=6, column=0, pady=10, padx=20, sticky='w')

        txt_dob = Entry(form_frame, textvariable=self.dob,  font=("times new roman", 16, "bold"), bd=5, relief=GROOVE)
        txt_dob.grid(row=6, column=1, pady=10, padx=20, sticky='w')
        #adress
        lbl_address = Label(form_frame, text="Address", bg="orange", fg="white", font=("times new roman", 16, "bold"))
        lbl_address.grid(row=7, column=0, pady=10, padx=20, sticky='w')

        self.txt_address = Text(form_frame, width=29, height=4)
        self.txt_address.grid(row=7, column=1, pady=10, padx=20, sticky='w')

        #2.Button Frame -------------------------------------------------------------------------------------------------
        # Button frame will place in form frame
        btn_frame = Frame(form_frame, bd=4, relief=RIDGE, bg="orange")
        btn_frame.place(x=20, y=520, width=400)

        #Buttons
        #buttons will place in button frame
        btnAdd = Button(btn_frame, text="Add", width=5, bg='green', bd=4, command=self.add_std).grid(row=0, column=0, padx=10, pady=10)
        btnUpdate = Button(btn_frame, text="Update", width=5, bg='yellow', bd=4, command=self.update_std).grid(row=0, column=1, padx=10, pady=10)
        btnDelete = Button(btn_frame, text="Delete", width=5, bg='crimson', bd=4, command=self.delete_std).grid(row=0, column=2, padx=10, pady=10)
        btnClear = Button(btn_frame, text="Clear", width=5, bg='gray', bd=4, command=self.clear).grid(row=0, column=3, padx=10, pady=10)


        #3.Details Frame -------------------------------------------------------------------------------------------------
        #details frame will place in root frame
        detail_frame = Frame(self.root, bd=4, relief=RIDGE, bg="yellow")
        detail_frame.place(x=500, y=100, width=800, height=600)

        #fields & label will be place in details frame
        #search By
        lbl_search = Label(detail_frame, text="Search By", bg="yellow", fg="black", font=("times new roman", 16, "bold"))
        lbl_search.grid(row=0, column=0, pady=10, padx=15, sticky='w')

        combo_search = ttk.Combobox(detail_frame, textvariable=self.search_by, width=10, font=("times new roman", 16, "bold"), state="readonly")
        combo_search['values'] = ('Roll_no', 'Name', 'contact')
        combo_search.grid(row=0, column=1, pady=10, padx=15, sticky='w')

        #Search
        txt_search = Entry(detail_frame, textvariable=self.search_txt, width=15, font=("times new roman", 16, "bold"), bd=5, relief=GROOVE)
        txt_search.grid(row=0, column=2, pady=10, padx=15, sticky='w')
        #buttons
        btnSearch = Button(detail_frame, text="Search", width=5, bd=4, pady=5, command=self.search_data).grid(row=0, column=3, padx=10, pady=10)
        btnShow = Button(detail_frame, text="Show All", width=5, bd=4, pady=5, command=self.fetch_data).grid(row=0, column=4, padx=10, pady=10)
        btnShow = Button(detail_frame, text="Exit", width=5, bd=4, pady=5, command=self.exit_app).grid(row=0, column=5, padx=10, pady=10)

        #4.Table Frame -------------------------------------------------------------------------------------------------
        # table frame will place in details frame
        table_frame = Frame(detail_frame, bd=4, relief=RIDGE, bg="crimson")
        table_frame.place(x=10, y=70, width=760, height=510)

        scroll_x = Scrollbar(table_frame, orient=HORIZONTAL)
        scroll_y = Scrollbar(table_frame, orient=VERTICAL)
        self.data_table = ttk.Treeview(table_frame, column=("roll", "name", "email", "gender", "phone", "dob", "address"), xscrollcommand=scroll_x.set, yscrollcommand=scroll_y.set)
        scroll_x.pack(side=BOTTOM, fill=X)
        scroll_y.pack(side=RIGHT, fill=Y)
        scroll_x.config(command=self.data_table.xview)
        scroll_y.config(command=self.data_table.yview)
        self.data_table.heading('roll', text="Roll")
        self.data_table.heading('name', text="Name")
        self.data_table.heading('email', text="Email")
        self.data_table.heading('phone', text="Contact")
        self.data_table.heading('gender', text="Gender")
        self.data_table.heading('dob', text="DOB")
        self.data_table.heading('address', text="Address")
        self.data_table['show']='headings'
        self.data_table.column("roll", width=50)
        self.data_table.column("name", width=100)
        self.data_table.column("email", width=150)
        self.data_table.column("gender", width=80)
        self.data_table.column("phone", width=100)
        self.data_table.column("dob", width=100)
        self.data_table.column("address", width=150)
        self.data_table.pack(fill=BOTH, expand=1)
        self.data_table.bind("<ButtonRelease-1>", self.get_cursor)
        self.data_table.tag_configure('odd', background='#E8E8E8')
        self.data_table.tag_configure('even', background='#DFDFDF')
        self.fetch_data()

    def get_std_by_id(self, roll):
        con = pymysql.connect(host='localhost', user='root', password='123', database='py_stm')
        cur = con.cursor()
        cur.execute("select * from students where roll_no ='" + str(roll) + "'")
        rows = cur.fetchall()
        return rows



    def add_std(self):
        if self.roll_no.get()!="" and self.name.get()!="" and self.email.get()!="" and self.gender.get()!="":
            res = self.get_std_by_id(self.roll_no.get())
            if len(res) > 0:
                messagebox.showerror("Error", "Duplicate Entry!!!")
                return
            con = pymysql.connect(host='localhost', user='admin', password='Admin@123', database='py_stm' )
            cur = con.cursor()
            cur.execute("insert into students values(%s,%s,%s,%s,%s,%s,%s)",(self.roll_no.get(),
                                                                             self.name.get(),
                                                                             self.email.get(),
                                                                             self.gender.get(),
                                                                             self.phone.get(),
                                                                             self.dob.get(),
                                                                             self.txt_address.get('1.0',END)
            ))
            con.commit()
            self.fetch_data()
            self.clear()
            con.close()
            messagebox.showinfo("Success", "Record has been inserted!")
        else:
            messagebox.showerror("Error", "All fields are required!!!")


    def fetch_data(self):
        con = pymysql.connect(host='localhost', user='root', password='123', database='py_stm' )
        cur = con.cursor()
        cur.execute("select * from students order by roll_no DESC")
        rows = cur.fetchall()
        if len(rows)>0:
            self.data_table.delete(*self.data_table.get_children())
            for row in rows:
                if row[0]%2==0:
                    self.data_table.insert('',END,values=row, tags="even")#tags used for odd-even row color
                else:
                    self.data_table.insert('', END, values=row, tags="odd")


            con.commit()
        con.close()
        self.search_by.set("")
        self.search_txt.set("")

    def clear(self):
        self.roll_no.set("")
        self.name.set("")
        self.email.set("")
        self.phone.set("")
        self.gender.set("")
        self.dob.set("")
        self.txt_address.delete("1.0", END)

    def get_cursor(self, ev):
        cursor_row = self.data_table.focus()
        if cursor_row:
            content = self.data_table.item(cursor_row)
            row = content['values']
            # print(row)
            self.roll_no.set(row[0])
            self.name.set(row[1])
            self.email.set(row[2])
            self.gender.set(row[3])
            self.phone.set(row[4])
            self.dob.set(row[5])
            self.txt_address.delete("1.0", END)
            self.txt_address.insert(END, row[6])
        else:
            pass


    def update_std(self):
        if self.roll_no.get() != "":
            con = pymysql.connect(host='localhost', user='admin', password='Admin@123', database='py_stm' )
            cur = con.cursor()
            result = cur.execute("update students set name=%s, email=%s, gender=%s, contact=%s, dob=%s, address=%s where  roll_no =%s",(self.name.get(),
                 self.email.get(),self.gender.get(),self.phone.get(),self.dob.get(),self.txt_address.get('1.0', END),self.roll_no.get()))
            if result:
                messagebox.showinfo('Updated', 'Student has been updated successfully!',icon='info' )
            con.commit()
            self.fetch_data()
            self.clear()
            con.close()
        else:
            messagebox.showerror("Error", "Please select a student!")


    def delete_std(self):
        if self.roll_no.get()!="":
            response = self.alert()
            if response=='yes':
                con = pymysql.connect(host='localhost', user='admin', password='Admin@123', database='py_stm' )
                cur = con.cursor()
                cur.execute("delete from students where roll_no=%s", self.roll_no.get())
                con.commit()
                con.close()
                self.fetch_data()
                self.clear()
            else:
                pass
        else:
            messagebox.showerror("Error", "Please select a student!")


    def exit_app(self):
        MsgBox = messagebox.askquestion('Exit Application', 'Are you sure you want to exit the application',
                                           icon='question')
        if MsgBox == 'yes':
            root.destroy()
        else:
            messagebox.showinfo('Return', 'You will now return to the application screen')

    def alert(self):
        MsgBox = messagebox.askquestion('Delete', 'Are you sure you want to delete the record',
                                        icon='warning')
        return MsgBox

    def search_data(self):
        if self.search_by.get()=="":
            messagebox.showerror("Error", "Provide search by value")
        elif self.search_txt.get()=="":
            messagebox.showerror("Error", "Provide search keyword")
        else:
            con = pymysql.connect(host='localhost', user='admin', password='Admin@123', database='py_stm' )
            cur = con.cursor()
            cur.execute("select * from students where "+str(self.search_by.get())+" Like '"+str(self.search_txt.get())+"%'" )
            rows = cur.fetchall()
            if len(rows)>0:
                self.data_table.delete(*self.data_table.get_children())
                for row in rows:
                    self.data_table.insert('',END,values=row)

                con.commit()
            con.close()




if __name__ == '__main__':
    root = Tk()
    ob = Student(root)
    root.mainloop()
