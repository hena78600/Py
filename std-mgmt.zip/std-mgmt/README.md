# std-mgmt
This is a student management desktop application with python3
![Student Management](https://github.com/py-app/std-mgmt/blob/master/screenshot.png)
