-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 19, 2020 at 10:02 AM
-- Server version: 5.7.29-0ubuntu0.18.04.1
-- PHP Version: 7.2.29-1+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `py_stm`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `roll_no` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `dob` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`roll_no`, `name`, `email`, `gender`, `contact`, `dob`, `address`) VALUES
(1, 'Gopal', 'gopal@gmail.com', 'Male', '8509848755', '03-04-1994', 'Panagarh, Wb, India\n\n'),
(2, 'Niraj', 'niraj@gmail.com', 'Male', '8509848758', '04-03-1994', 'Kolkata,WB, India\n\n\n\n\n\n'),
(3, 'Mukesh', 'mukesh@gmail.com', 'Male', '8346807648', '01-01-1993', 'Bihar, India\n\n\n'),
(4, 'Billy', 'billy@gmail.com', 'Female', '5698784512', '02-02-1992', '2/30 Science Park, USA\n'),
(6, 'Alex', 'alex@gmail.com', 'Male', '1234569870', '01-01-1990', 'Florida, USA\n\n'),
(7, 'Ritesh', 'ritesh@gmail.com', 'Male', '1236547891', '01-01-1980', 'Durgapur\n'),
(8, 'Chandan', 'chandan@mail.com', 'Male', '1336548790', '01-01-1996', 'Durgapur\n\n'),
(9, 'Rocky', 'rocky@mail.com', 'Male', '1236547890', '01-01-1990', 'Mayabazar, Durgapur\n'),
(10, 'Debajit', 'deb@gmail.com', 'Male', '3654890270', '01-01-1982', '2/39, Saltlake, Kolkata\n'),
(11, 'Hena', 'hena@yahoo.com', 'Female', '3214569870', '09-09-1995', 'Kulti, Asansol, WB, India\n\n\n'),
(12, 'Mohoua', 'moh@hotmail.com', 'Female', '4563217890', '01-01-1995', 'Durgapur, WB, India\n\n'),
(13, 'Kim', 'kim@gmail.com', 'Male', '7896541230', '01-01-1989', 'Brazil\n'),
(14, 'Buni', 'buni@gmail.com', 'Female', '1236548790', '01-01-1997', 'Panagarh, WB, India\n'),
(15, 'Ximping', 'xping@china.com', 'Male', '1563248970', '01-01-1980', 'Hunhai, Chaina\n\n'),
(16, 'Modi', 'pm@govt.com', 'Male', '1112360', '01-01-1979', 'Delhi, India\n\n\n\n'),
(17, 'Trump', 'trump@usa.com', 'Male', '3214569820', '01-01-1981', 'USA\n\n'),
(18, 'Tungafdfadsfdsfsd', 'tunga@gmail.com', 'Male', '3214569875', '02-02-1985', 'UP, India\n\n\n'),
(19, 'Didi', 'didi@gmail.com', 'Female', '85098487566', '01-01-1987', 'Panagarh, WB, Indaia\n\n\n'),
(20, 'Birat', 'kohli@gmail.com', 'Male', '3698521470', '01-01-1985', 'Mumbai, India\n\n\n\n'),
(21, 'Ananth', 'ananth@gmail.com', 'Male', '1478529630', '01-01-1982', 'Chennai, India\n\n'),
(22, 'Chandranath', 'cd@gmail.com', 'Male', '2587964130', '01-01-1986', 'Kolkata, India\n'),
(23, 'Swarup', 'sd@boss.com', 'Male', '1478529630', '01-01-1986', 'Durgapur, India\n\n'),
(24, 'Raj', 'raj@gmail.com', 'Male', '1236547892', '01-01-1993', 'Bhupal, MP, India\n'),
(25, 'Bigboss', 'bb@gmail.com', 'Male', '8754963212', '01-01-1990', 'Nepal, India\n\n\n\n'),
(26, 'Sudipto', 'sudipto@gmail.com', 'Male', '4569857123', '04-05-1993', 'Durgapur, India\n\n'),
(27, 'Harsh', 'hr@gmail.com', 'Male', '1236547890', '01-01-2015', 'Durgapur, WB\n\n\n\n'),
(30, 'iman', 'iman@gmail.com', 'Male', '8509848755', '06-06-2012', 'gopalpur\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`roll_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
